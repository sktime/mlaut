import os
from estimators import estimators
from delgado_datasets import download_and_extract_datasets
from mlaut.data import Data
from mlaut.experiments import Orchestrator
from mlaut.analyze_results import AnalyseResults
from mlaut.analyze_results.scores import ScoreAccuracy

datasets, metadata = download_and_extract_datasets()

os.mkdir('data')
data = Data()
input_io = data.open_hdf5('data/delgado.h5', mode='a')
for item in zip(datasets, metadata):
    dts=item[0]
    meta=item[1]
    input_io.save_pandas_dataset(dataset=dts, save_loc='/delgado_datasets', metadata=meta)


out_io = data.open_hdf5('data/delgado-classification.h5', mode='a')
dts_names_list, dts_names_list_full_path = data.list_datasets(hdf5_io=input_io, hdf5_group='delgado_datasets/')
split_dts_list = data.split_datasets(hdf5_in=input_io, hdf5_out=out_io, dataset_paths=dts_names_list_full_path)


orchest = Orchestrator(hdf5_input_io=input_io, 
                            hdf5_output_io=out_io, 
                            dts_names=dts_names_list,
                            original_datasets_group_h5_path='delgado_datasets/')
orchest.run(modelling_strategies=estimators)

analyze = AnalyseResults(hdf5_output_io=out_io, 
                        hdf5_input_io=input_io, 
                        input_h5_original_datasets_group='delgado_datasets/', 
                        output_h5_predictions_group='experiments/predictions/')

score_accuracy = ScoreAccuracy()

 
(errors_per_estimator, 
 errors_per_dataset_per_estimator, 
 errors_per_dataset_per_estimator_df) = analyze.prediction_errors(score_accuracy, estimators)

sign_df, sign_df_pivot = analyze.sign_test(errors_per_estimator)
avg_and_std_error = analyze.average_and_std_error(errors_per_estimator)
avg_rank = analyze.ranks(errors_per_estimator, ascending=False)
avg_training_time, training_time_per_dataset = analyze.average_training_time(estimators)
avg_training_time, training_time_per_dataset = analyze.average_training_time(estimators)
cohens_d = analyze.cohens_d(errors_per_estimator)
t_test, t_test_df = analyze.t_test(errors_per_estimator)
t_test_bonferroni_df = analyze.t_test_with_bonferroni_correction(errors_per_estimator)
a, wilcoxon_df_multiindex = analyze.wilcoxon_test(errors_per_estimator)
_, ranksum_pivot = analyze.ranksum_test(errors_per_estimator)
_, friedman_test_df = analyze.friedman_test(errors_per_estimator)
nemeniy_test = analyze.nemenyi(errors_per_estimator)